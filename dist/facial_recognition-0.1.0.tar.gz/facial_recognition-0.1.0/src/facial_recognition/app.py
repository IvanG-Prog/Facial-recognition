from flask import Flask, request, jsonify
import registers
import access
import cv2

app= Flask(__name__)

@app.route('/')
def index():
    return '''
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8" />
<title>Facial - recognition</title>
<style>
  body {
    margin: 0;
    height: 100vh;
    background: linear-gradient(135deg, #89f7fe 0%, #66a6ff 100%);
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    font-family: Arial, sans-serif;
    color: #ffffff;
    text-align: center;
  }
  h1 {
    font-size: 3em;
    margin-bottom: 20px;
  }
  img {
    width: 150px;
    margin-bottom: 20px;
  }
  .btn {
    padding: 15px 30px;
    margin: 10px;
    font-size: 1.2em;
    border: none;
    border-radius: 8px;
    cursor: pointer;
    transition: background 0.3s;
    background-color: #fff;
    color: #333;
  }
  .btn:hover {
    background-color: #f0f0f0;
  }
</style>
</head>
<body>
  <img src="https://images.unsplash.com/photo-1506368265446-e4dcbd427a91?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80" alt="Logo" />
  <h1>Facial-recognition</h1>
  <button class="btn" onclick="window.location.href='/register'">Registration</button>
  <button class="btn" onclick="window.location.href='/access'">Access</button>
</body>
</html>
    '''

@app.route('/register')
def register_page():
    return '''
<h2>User registration</h2>
<form id="registroForm">
    <input name="name" placeholder="Name"><br>
    <input name="lastname" placeholder="Last name"><br>
    <input name="id" placeholder="ID"><br>
    <input name="username" placeholder="User"><br>
    <button type="button" onclick="register()">Register</button>
</form>
<script>
function register() {
    const form = document.getElementById('registroForm');
    const datos = {
        name: form.name.value,
        last name: form.last name.value,
        id: form.id.value,
        username: form.username.value
    };
    fetch('/register', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify(datos)
    }).then(response => response.json())
    .then(data => alert(data.message))
    .catch(err => alert('Error: ' + err));
}
</script>
    '''

# Endpoint para procesar registro
@app.route('/register', methods=['POST'])
def register():
    datos = request.get_json()
    name = datos.get('name')
    lastname = datos.get('last name')
    id_card = datos.get('id')
    username = datos.get('username')
    #  call to register
    success, message = registers.register(name, lastname, id_card, username, registers.base_path)
    if success:
        return jsonify("status : ok message :", message), 200
    else:
        return jsonify("status: error message:" ,message), 400




@app.route('/access')
def acces_page():
    return '''
<h2>User access</h2>
<form id="accesoForm">
    <input name="username" placeholder="User"><br>
    <button type="button" onclick="access()">Access</button>
</form>
<script>
function main() {
    const form = document.getElementById('accesoForm');
    const username = form.username.value;
    fetch('/access', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({username: username})
    }).then(response => response.json())
    .then(data => alert(data.message))
    .catch(err => alert('Error: ' + err));
}
</script>
    '''

# Endpoint para procesar acceso
@app.route('/access', methods=['POST'])
def acceso_usuario():
    data = request.get_json()
    username = data.get('username')
    success, message = access.verificar_acceso(username)
    if success:
        return jsonify({"status": "ok", "message": message}), 200
    else:
        return jsonify({"status": "error", "message": message}), 400


if __name__ == '__main__':
    app.run(debug=True)
